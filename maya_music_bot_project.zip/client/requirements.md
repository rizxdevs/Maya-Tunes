## Packages
framer-motion | Complex animations and page transitions
recharts | Statistics visualization
clsx | Class name utility
tailwind-merge | Class name utility

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Outfit'", "sans-serif"],
  body: ["'DM Sans'", "sans-serif"],
  mono: ["'JetBrains Mono'", "monospace"],
}
